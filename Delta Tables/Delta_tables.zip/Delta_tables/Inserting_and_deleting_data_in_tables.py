# Databricks notebook source
#importing modules
from pyspark.sql import SparkSession
from delta.tables import *

# COMMAND ----------

#creating delta tables
Dd = DeltaTable.create(spark) \
    .tableName('employe_demo') \
    .addColumn('emp_id','INT') \
    .addColumn('emp_Name','STRING') \
    .addColumn('gender','STRING') \
    .addColumn('salary','INT') \
    .addColumn('dept','STRING') \
    .property('description','table created for demo purpose') \
    .location('/FileStore/table/delta/createtable1') \
    .execute() 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from employe_demo

# COMMAND ----------

# DBTITLE 1,insert data by using sql method
# MAGIC %sql
# MAGIC insert into employe_demo values(100,'shiva','M',2000,'IT');

# COMMAND ----------

# DBTITLE 1,Query the table using spark.sql method
display(spark.sql('select * from employe_demo'))

# COMMAND ----------

# DBTITLE 1,Dataframe insert
from pyspark.sql.types import IntegerType,StringType,StructType,StructField
employe_data = [(200,'sai','M',8000,'HR'),(300,'niranjan','M',9000,'De'),(400,'setha','F',10000,'BI')]

employe_schema = StructType([ \
    StructField('emp_id',IntegerType(),False), \
    StructField('emp_name',StringType(),True), \
    StructField('gender',StringType(),True), \
    StructField('salary',IntegerType(),True), \
    StructField('dept',StringType(),True) \
])

df = spark.createDataFrame(data=employe_data, schema = employe_schema)
display(df)

# COMMAND ----------

deltadf =df.write.format('delta').mode('append').saveAsTable('employe_demo')

# COMMAND ----------

# DBTITLE 1,Dataframe insert into method
employe_data =[(300,'charan','M',6000,'sales')]

employe_schema = StructType([ \
    StructField('emp_id',IntegerType(),False), \
    StructField('emp_name',StringType(),True), \
    StructField('gender',StringType(),True), \
    StructField('salary',StringType(),True), \
    StructField('dept',StringType(),True) \
])

df1 = spark.createDataFrame(data=employe_data, schema= employe_schema)
display(df1)

# COMMAND ----------

df1.write.insertInto('employe_demo',overwrite=False)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from employe_demo

# COMMAND ----------

# DBTITLE 1,Insert using Temp view
df1.createOrReplaceTempView('delta_data')

# COMMAND ----------

# querying the temp view delta_data
%sql
select * from delta_data

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into employe_demo
# MAGIC select * from delta_data

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from employe_demo

# COMMAND ----------

# DBTITLE 1,spark sql insert
spark.sql('insert into employe_demo select * from delta_data')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from employe_demo

# COMMAND ----------

# DBTITLE 1,Method:1 SQL
# MAGIC %sql
# MAGIC delete from employe_demo where emp_id =100

# COMMAND ----------

# DBTITLE 1,Method:1 SQL using Delta location
# MAGIC %sql
# MAGIC Delete from delta.`/FileStore/table/delta/createtable1` where emp_id =200

# COMMAND ----------

# DBTITLE 1,Method:1 spark SQL
spark.sql("delete from employe_demo where emp_id == 300")

# COMMAND ----------

# DBTITLE 1,Multiple conditions using SQL predicate
spark.sql("delete from employe_demo where emp_id == 300 and gender = 'M'")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from employe_demo

# COMMAND ----------

