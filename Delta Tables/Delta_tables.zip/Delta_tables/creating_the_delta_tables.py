# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ###Delta table 

# COMMAND ----------

# DBTITLE 1,import modules
#importing modules
from pyspark.sql import SparkSession
from delta.tables import*

# COMMAND ----------

# DBTITLE 1,create delta table using spark
#creating delta tables
Dd = DeltaTable.create(spark) \
    .tableName('employe_demo') \
    .addColumn('emp_id','INT') \
    .addColumn('emp_Name','STRING') \
    .addColumn('gender','STRING') \
    .addColumn('salary','INT') \
    .addColumn('dept','STRING') \
    .property('description','table created for demo purpose') \
    .location('/FileStore/table/delta/createtable1') \
    .execute()  

# COMMAND ----------

# DBTITLE 1,Query the table
# MAGIC %sql
# MAGIC select * from default.employe_demo;

# COMMAND ----------

# DBTITLE 1,Another method in spark to create Delta Table
from delta.tables import *
DeltaTable.createIfNotExists(spark) \
    .tableName('employe_demo1') \
    .addColumn('emp_id','INT') \
    .addColumn('emp_name','STRING') \
    .addColumn('gender','STRING') \
    .addColumn('salary','INT') \
    .addColumn('dep','STRING') \
    .execute()

# COMMAND ----------

from delta.tables import *
DeltaTable.createOrReplace(spark) \
    .tableName('employe_demo1') \
    .addColumn('emp_id','INT') \
    .addColumn('emp_name','STRING') \
    .addColumn('gender','STRING') \
    .addColumn('salary','INT') \
    .addColumn('dep','STRING') \
    .execute()

# COMMAND ----------

# DBTITLE 1,Create delta table in SQL
# MAGIC %sql
# MAGIC CREATE TABLE employe_demo2(
# MAGIC   emp_id INT,
# MAGIC   emp_Name STRING,
# MAGIC   gender STRING,
# MAGIC   salary INT,
# MAGIC   dept STRING
# MAGIC   )USING DELTA

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists employe_demo2(
# MAGIC   emp_id INT,
# MAGIC   emp_Name STRING,
# MAGIC   gender STRING,
# MAGIC   salary INT,
# MAGIC   dept STRING
# MAGIC   )using delta

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table employe_demo2(
# MAGIC   emp_id INT,
# MAGIC   emp_Name STRING,
# MAGIC   gender STRING,
# MAGIC   salary INT,
# MAGIC   dept STRING
# MAGIC   )using delta
# MAGIC   location 'dbfs:/user/hive/warehouse/employe_demo2'

# COMMAND ----------

# DBTITLE 1,using Pyspark
#creating  dataframe and using df to create delta_table
employe_data = [(100,'shiva','M',2000,'IT('),
                (200,'sai','M',8000,'HR'),
                (300,'charan','M',6000,'sales')]
employe_schema = ['emp_id','emp_name','gender','salary','dept']

df = spark.createDataFrame(data=employe_data,schema = employe_schema)

display(df)

# COMMAND ----------

# DBTITLE 1,convert dataframe into delta table
df.write.format('delta').saveAsTable('default.employe_demo3')