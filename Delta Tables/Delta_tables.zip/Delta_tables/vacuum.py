# Databricks notebook source
# DBTITLE 1,create table
from delta.tables import *
DeltaTable.create(spark) \
    .tableName('scd2demo1') \
    .addColumn('pk1','INT') \
    .addColumn('pk2','STRING') \
    .addColumn('dim1','INT') \
    .addColumn('dim2','INT') \
    .addColumn('dim3','INT') \
    .addColumn('dim4','INT') \
    .addColumn('active_status', 'STRING') \
    .addColumn('start_date','TIMESTAMP') \
    .addColumn('end_date','TIMESTAMP') \
    .location('/Filestore/tables/scd2demo1') \
    .execute()

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into scd2demo1 values (111,'unit1',200,500,600,700,'N','2014-07-02 06:14:00','2024-08-08 07:14:00');
# MAGIC insert into scd2demo1 values (113,'unit3',205,506,608,709,'N','2014-07-05 06:14:00','2024-08-09 07:14:00');
# MAGIC insert into scd2demo1 values (112,'unit2',204,504,604,704,'Y','2014-07-03 06:14:00','2024-08-09 07:14:00');
# MAGIC insert into scd2demo1 values (114,'unit4',205,504,602,701,'y','2014-07-07 06:14:00','2024-08-09 07:14:00');

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into scd2demo1 values (115,'unit5',200,500,600,700,'N','2014-07-02 06:14:00','2024-08-08 07:14:00');
# MAGIC insert into scd2demo1 values (116,'unit6',205,506,608,709,'N','2014-07-05 06:14:00','2024-08-09 07:14:00');
# MAGIC insert into scd2demo1 values (117,'unit7',204,504,604,704,'Y','2014-07-03 06:14:00','2024-08-09 07:14:00');
# MAGIC insert into scd2demo1 values (118,'unit8',205,504,602,701,'y','2014-07-07 06:14:00','2024-08-09 07:14:00');

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from scd2demo1;

# COMMAND ----------

# MAGIC %sql
# MAGIC delete from scd2demo1 where pk1 = 111;

# COMMAND ----------

# MAGIC %sql
# MAGIC update scd2demo1 set dim1 = 100 where pk1=112;

# COMMAND ----------

# DBTITLE 1,optimize
# MAGIC %sql
# MAGIC optimize scd2demo1; 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from scd2demo1;

# COMMAND ----------

# DBTITLE 1,History
# MAGIC %sql
# MAGIC describe history scd2demo1;

# COMMAND ----------

# DBTITLE 1,list the part files in that location
# MAGIC %fs ls dbfs:/Filestore/tables/scd2demo1

# COMMAND ----------

# MAGIC %sql
# MAGIC SET spark.databricks.delta.retentionDurationCheck.enabled = false;
# MAGIC SET spark.databricks.delta.vacuum.logging.enabled = true;

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### DRY RUN is used to show the files which are going to be deleted.

# COMMAND ----------

# DBTITLE 1,vacuum dry run
# MAGIC %sql
# MAGIC 
# MAGIC VACUUM scd2demo1 RETAIN 0 HOURS DRY RUN

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC VACUUM scd2demo1

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### z-order

# COMMAND ----------

# MAGIC %sql
# MAGIC optimize scd2demo1 zorder pk1

# COMMAND ----------

