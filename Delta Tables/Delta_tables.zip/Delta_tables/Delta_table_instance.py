# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ### Delta Instance 

# COMMAND ----------

#importing modules
from pyspark.sql import SparkSession
from delta.tables import*

# COMMAND ----------

# DBTITLE 1,create delta table
DT = DeltaTable.create(spark) \
    .tableName('Employe_demo3') \
    .addColumn('emp_id','INT') \
    .addColumn('emp_name','STRING') \
    .addColumn('gender','STRING') \
    .addColumn('salary','INT') \
    .addColumn('dept','STRING') \
    .property('description','table created for demo purpose') \
    .location('/FileStore/table/delta/createtable3') \
    .execute()

# COMMAND ----------

# DBTITLE 1,inserting the values
# MAGIC %sql
# MAGIC insert into employe_demo3 values(100,'shiva','M',2000,'IT');
# MAGIC insert into employe_demo3 values(200,'sai','M',8000,'HR');
# MAGIC insert into employe_demo3 values(300,'charan','M',6000,'sales');
# MAGIC insert into employe_demo3 values(400,'niranjan','M',7000,'DE');
# MAGIC insert into employe_demo3 values(500,'setha','F',8000,'BI')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from employe_demo3

# COMMAND ----------

deltaInstance1 = DeltaTable.forPath(spark,'/FileStore/table/delta/createtable3')

# COMMAND ----------

display(deltaInstance1.toDF())

# COMMAND ----------

# MAGIC %sql
# MAGIC delete from  employe_demo3 where emp_id =100

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from  employe_demo3

# COMMAND ----------

deltaInstance1.delete('emp_id =200')

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history employe_demo3 

# COMMAND ----------

