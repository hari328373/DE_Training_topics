# Databricks notebook source
from pyspark.sql import SparkSession
from delta.tables import*

# COMMAND ----------

# MAGIC %sql
# MAGIC create table Employee_details(
# MAGIC emp_id int,
# MAGIC emp_name string,
# MAGIC dept string)

# COMMAND ----------

# MAGIC %sql 
# MAGIC 
# MAGIC insert into Employee_details values(100,'shiva','Sales'),(101,'Sai','Sales'),(102,'cherry','HR'),(103,'pandu','HR'),(104,'vasu','Sales');

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from Employee_details;

# COMMAND ----------

# DBTITLE 1,Metadata of table
# MAGIC %sql
# MAGIC describe extended Employee_details;

# COMMAND ----------

# MAGIC %sql
# MAGIC delete from Employee_details where emp_id = 104;

# COMMAND ----------

# DBTITLE 1,History of table
# MAGIC %sql
# MAGIC DESCRIBE history Employee_details;

# COMMAND ----------

# DBTITLE 1,method:1 Pyspark - Timestamp+Table
df = spark.read \
  .format('delta') \
  .option('timestamp','2023-02-23T09:54:53.000+0000') \
  .table('Employee_details')
display(df)

# COMMAND ----------

# DBTITLE 1,method:2 Pyspark - Timestamp+Table
df = spark.read \
  .format('delta') \
  .option('timestamp','2023-02-23T09:54:53.000+0000') \
  .load('dbfs:/user/hive/warehouse/employee_details')
display(df)

# COMMAND ----------

# DBTITLE 1,method:3 Pyspark - Timestamp+Table
df = spark.read \
  .format('delta') \
  .option('versionAsof', 2) \
  .load('dbfs:/user/hive/warehouse/employee_details')
display(df)

# COMMAND ----------

# DBTITLE 1,method:4 Pyspark - Timestamp+Table
df = spark.read \
  .format('delta') \
  .option('versionAsof', 1) \
  .table('Employee_details')
display(df)

# COMMAND ----------

# DBTITLE 1,create delta table for restore command
from delta.tables import *
DeltaTable.create(spark) \
    .tableName('scd2demo') \
    .addColumn('pk1','INT') \
    .addColumn('pk2','STRING') \
    .addColumn('dim1','INT') \
    .addColumn('dim2','INT') \
    .addColumn('dim3','INT') \
    .addColumn('dim4','INT') \
    .addColumn('active_status', 'STRING') \
    .addColumn('start_date','TIMESTAMP') \
    .addColumn('end_date','TIMESTAMP') \
    .location('/Filestore/tables/scd2demo') \
    .execute()

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into scd2demo values (111,'unit1',200,500,600,700,'N','2014-07-02 06:14:00','2024-08-08 07:14:00'),(113,'unit3',205,506,608,709,'N','2014-07-05 06:14:00','2024-08-09 07:14:00'),((112,'unit2',204,504,604,704,'Y','2014-07-03 06:14:00','2024-08-09 07:14:00')),(114,'unit4',205,504,602,701,'y','2014-07-07 06:14:00','2024-08-09 07:14:00')

# COMMAND ----------

# DBTITLE 1,Explore the table
# MAGIC %sql
# MAGIC select * from scd2demo

# COMMAND ----------

# DBTITLE 1,create Delta Table Instance
targettTablefrom delta import *
targettTable  = DeltaTable.forPath(spark,"/Filestore/tables/scd2demo")

# COMMAND ----------

# DBTITLE 1,List down Version history
display(targettTable.history())

# COMMAND ----------

# DBTITLE 1,Restore using Version number
targettTable.restoreToVersion(2)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from scd2demo

# COMMAND ----------

# DBTITLE 1,Restore using Timestamp
targettTable.restoreToTimestamp('2023-02-23T13:07:01.000+0000')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from scd2demo

# COMMAND ----------

